import { Injectable } from '@angular/core';
import { User } from '../modal/interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

    constructor(private http: HttpClient) { }

    private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

    sendImageOrFileToServer(fileToUpload: File, bodyContent ?) {
        const fd = new FormData();
        fd.append('file', fileToUpload, fileToUpload.name);
        // const body = {
        //     base64: fileToUpload
        // };
        if (bodyContent) {
            // fd.append('inputType', bodyContent.inputType);
            // fd.append('extension', bodyContent.extension);
        }
        return this.http.post('http://1a8bf3f5.ngrok.io/textulizer/v1/extractText', fd, { observe: 'response' });
    }
}
