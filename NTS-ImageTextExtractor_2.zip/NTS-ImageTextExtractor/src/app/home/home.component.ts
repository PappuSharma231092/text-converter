import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpEventType, HttpClientModule } from '@angular/common/http';
import { SnackbarService } from '../core/helper/snackbar.service';
import { UserServiceService } from '../core/services/user-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(
    private http: HttpClient,
    private snackbar: SnackbarService,
    private apiRequest: UserServiceService
    ) { }

  showDragDropFileContainer = true;
  showTextContainer = true;
  showLoader = false;
  showDragDropPDFFileContainer = true;
  textImage = '';
  fileToUpload: File = null;
  pdfFile: File = null;
  pdfSrc = null;
  imgURL: any;
  imageData: any = [];
  public message: string;

  files: any = [];

  page  = 1;
  totalPages: number;
  isLoaded = false;

  afterLoadComplete(pdfData: any) {
    this.totalPages = pdfData.numPages;
    this.isLoaded = true;
  }

  nextPage() {
    this.page++;
  }

  prevPage() {
    this.page--;
  }

  uploadFile(files) {
    if (files.length === 0) {
      return;
    }

    // tslint:disable-next-line:prefer-for-of
    // const mimeType = files[0].type;
    // if (mimeType.match(/image\/*/) == null) {
    //   this.message = 'Only images are supported.';
    //   console.log('not supported file');
    // }

    const reader = new FileReader();
    this.fileToUpload = files[0];
    console.log(this.fileToUpload.type);
    reader.readAsDataURL(files[0]);
    reader.onload = (event) => {
      this.imageData = reader.result;
      console.log(reader.result);
      this.showDragDropFileContainer = false;
      this.processFile(this.fileToUpload, this.imageData);
    };
  }

  processFile(file, fileData) {
    this.showLoader = true;
    const fileType = this.getTypeOfFile(file);

    const bodyContent = {
      inputType: fileType.toLowerCase() === 'pdf' ? 'pdf' : 'image',
      extension: fileType
    };

    this.apiRequest.sendImageOrFileToServer(file, bodyContent)
      .subscribe(resp => {
        console.log(resp);
        this.snackbar.open('Successfully Processed the file', '', { type: 'success'});
        this.showLoader = false;
      }, err => {
        this.snackbar.open('Error in getting Text ...!', '', {type: 'warning'});
        this.showLoader = false;
      });
    }
  // processFile() {
  //   this.showLoader = true;
  //   const fd = new FormData();
  //   fd.append('base64', this.fileToUpload, this.fileToUpload.name);
  //   this.http.post('http://b803da03.ngrok.io/textulizer/v2/extractText', fd)
  //   .subscribe(resp => {
  //     console.log(resp);
  //     this.snackbar.open('Successfully Processed the file', 'success');
  //     this.showLoader = false;
  //   }, err => {
  //       this.snackbar.open('Error in Uploding ...!', 'error');
  //       this.showLoader = false;
  //   });

    // Method to calculate the % of data got in the response

    // this.http.post('http://b803da03.ngrok.io/textulizer/v2/extractText', fd, {
    //   reportProgress: true,
    //   observe: 'events'
    // })
    //   .subscribe(event => {
    //     if (event.type === HttpEventType.UploadProgress) {
    //       console.log('Progress = ' + Math.round(event.loaded / event.total * 100) + '%');
    //     } else if (event.type === HttpEventType.Response) {
    //       console.log(event);
    //     }
    //     console.log(event);
    //   });

    // this.http.post('URL', this.fileToUpload, {
    //   reportProgress: true,
    //   observe: 'events'
    // })
    //   .subscribe(event => {
    //     if (event.type === HttpEventType.UploadProgress) {
    //       console.log('Progress = ' + Math.round(event.loaded / event.total * 100) + '%');
    //     } else if (event.type === HttpEventType.Response) {
    //       console.log(event);
    //     }
    //     console.log(event);
    //   });
  // }

getTypeOfFile(file) {
  return file.type.split('/')[1];
}

  reset() {
    this.files = [];
    this.imageData = null;
    this.showDragDropFileContainer = true;
    this.showDragDropPDFFileContainer = true;
    this.pdfSrc = null;
    this.textImage = '';
  }

  submitText() {

  }

  onFileSelected() {
    const doc: any = document.querySelector('#file');

    if (typeof (FileReader) !== 'undefined') {
      const reader = new FileReader();
      this.pdfFile = doc.files[0];
      reader.onload = (e: any) => {
        this.pdfSrc = e.target.result;
        this.showDragDropPDFFileContainer = false;
        this.processFile(this.pdfFile, this.pdfSrc);
      };
      console.log(doc.files[0].type);
      reader.readAsDataURL(doc.files[0]);
      // reader.readAsArrayBuffer(doc.files[0]);
    }
  }

  ngOnInit(): void {
  }

}
