import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpEventType, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private http: HttpClient) { }

  showDragDropFileContainer = true;
  showTextContainer = true;
  textImage = '';
  fileToUpload: File = null;
  imgURL: any;
  imageUrls: any = [];
  public message: string;

  files: any = [];

  uploadFile(files) {
    if (files.length === 0) {
      return;
    }

    // tslint:disable-next-line:prefer-for-of
    // const mimeType = files[0].type;
    // if (mimeType.match(/image\/*/) == null) {
    //   this.message = 'Only images are supported.';
    //   console.log('not supported file');
    // }

    const reader = new FileReader();
    this.fileToUpload = files[0];
    reader.readAsDataURL(files[0]);
    reader.onload = (event) => {
      this.imageUrls = reader.result;
      console.log(reader.result);
      this.showDragDropFileContainer = false;
      this.sendImageToServer();
    };
  }

  deleteAttachment(index) {
    this.files.splice(index, 1);
  }

  sendImageToServer() {
    const fd = new FormData();
    fd.append('base64', this.fileToUpload, this.fileToUpload.name);
    this.http.post('http://b803da03.ngrok.io/textulizer/v2/extractText', fd)
    .subscribe(resp => {
      console.log(resp);
    });

    // Method to calculate the % of data got in the response

    // this.http.post('http://b803da03.ngrok.io/textulizer/v2/extractText', fd, {
    //   reportProgress: true,
    //   observe: 'events'
    // })
    //   .subscribe(event => {
    //     if (event.type === HttpEventType.UploadProgress) {
    //       console.log('Progress = ' + Math.round(event.loaded / event.total * 100) + '%');
    //     } else if (event.type === HttpEventType.Response) {
    //       console.log(event);
    //     }
    //     console.log(event);
    //   });

    // this.http.post('URL', this.fileToUpload, {
    //   reportProgress: true,
    //   observe: 'events'
    // })
    //   .subscribe(event => {
    //     if (event.type === HttpEventType.UploadProgress) {
    //       console.log('Progress = ' + Math.round(event.loaded / event.total * 100) + '%');
    //     } else if (event.type === HttpEventType.Response) {
    //       console.log(event);
    //     }
    //     console.log(event);
    //   });
  }

  reset() {
    this.files = [];
    this.imageUrls = null;
    this.showDragDropFileContainer = true;
    this.textImage = '';
  }

  submitText() {

  }

  ngOnInit(): void {
  }

}
